"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// @ts-nocheck
const { addConfigOptions, addAccountOptions } = require('../lib/commonOpts');
const list = require('./functions/list');
const deploy = require('./functions/deploy');
const server = require('./functions/server');
const { i18n } = require('../lib/lang');
const i18nKey = 'commands.functions';
exports.command = 'functions';
exports.describe = i18n(`${i18nKey}.describe`);
exports.builder = yargs => {
    addConfigOptions(yargs);
    addAccountOptions(yargs);
    yargs
        .command({
        ...list,
        aliases: 'ls',
    })
        .command(deploy)
        .command(server)
        .demandCommand(1, '');
    return yargs;
};
