"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// @ts-nocheck
module.exports = {
    'api-sample': require('./api-sample'),
    app: require('./app'),
    function: require('./function'),
    module: require('./module'),
    'react-app': require('./react-app'),
    template: require('./template'),
    'vue-app': require('./vue-app'),
    'webpack-serverless': require('./webpack-serverless'),
    'website-theme': require('./website-theme'),
};
