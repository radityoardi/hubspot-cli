/**
 * To add a new asset type: See vue-app.js for a simple example
 * 1. Create a new file under the `create` directory with the command name being the name of the file
 * 2. The file _must_ export a `dest` function and an `execute` function.  See below for details
 * Note: No changes should be needed to this file when adding new types, unless you need new functionality
 *
 * @export {(Data) => String} dest - A function returning the destination of the asset we are creating
 * @export {(Data) => Object=} execute - The code called once all other checks pass. This should contain the logic
 *                                       for handling your command.  Optionally return an object containing KV pairs
 *                                       of any context or data you want passed along to usage tracking
 * @export {Boolean=} hidden - If true, the command will not show up in --help
 * @export {(Data) => Boolean=} validate - If provided, return true if it passes validation, false otherwise.
 *                                         If not provided, validation will automatically succeed
 *
 * The Data object contains
 * {
 *   assetType: String - Type of the asset (e.g. api-sample, react-app, template)
 *   name:      String - Filename of the asset
 *   dest:      String - The path specified by the user on where to create the asset
 *   internal:  Boolean - A flag for retrieving the internal spec for the asset type
 *   options:   Object - The options object passed to the command by Yargs
 * }
 */
export {};
