export declare const STRING_WITH_NO_SPACES_REGEX: RegExp;
