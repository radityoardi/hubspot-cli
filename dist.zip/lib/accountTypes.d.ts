import { CLIAccount } from '@hubspot/local-dev-lib/types/Accounts';
export declare function isStandardAccount(accountConfig: CLIAccount): boolean;
export declare function isSandbox(accountConfig: CLIAccount): boolean;
export declare function isStandardSandbox(accountConfig: CLIAccount): boolean;
export declare function isDevelopmentSandbox(accountConfig: CLIAccount): boolean;
export declare function isDeveloperTestAccount(accountConfig: CLIAccount): boolean;
export declare function isAppDeveloperAccount(accountConfig: CLIAccount): boolean;
