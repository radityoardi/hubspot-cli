export declare function hasFlag(flag: string, argv?: string[]): boolean;
