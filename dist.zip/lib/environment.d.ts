export declare function getPlatform(): string;
