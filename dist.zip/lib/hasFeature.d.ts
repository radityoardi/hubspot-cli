export declare function hasFeature(accountId: number, feature: string): Promise<boolean>;
