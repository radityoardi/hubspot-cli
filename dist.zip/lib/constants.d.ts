export declare const HUBSPOT_PROJECT_COMPONENTS_GITHUB_PATH: "HubSpot/hubspot-project-components";
export declare const DEFAULT_PROJECT_TEMPLATE_BRANCH: "main";
export declare const FEEDBACK_OPTIONS: {
    readonly BUG: "bug";
    readonly GENERAL: "general";
};
export declare const FEEDBACK_URLS: {
    readonly BUG: "https://github.com/HubSpot/hubspot-cli/issues/new";
    readonly GENERAL: "https://docs.google.com/forms/d/e/1FAIpQLSejZZewYzuH3oKBU01tseX-cSWOUsTHLTr-YsiMGpzwcvgIMg/viewform?usp=sf_link";
};
export declare const FEEDBACK_INTERVAL: 10;
export declare const HUBSPOT_FOLDER: "@hubspot";
export declare const MARKETPLACE_FOLDER: "@marketplace";
export declare const CONFIG_FLAGS: {
    readonly USE_CUSTOM_OBJECT_HUBFILE: "useCustomObjectHubfile";
};
export declare const POLLING_DELAY = 2000;
export declare const POLLING_STATUS: {
    readonly SUCCESS: "SUCCESS";
    readonly ERROR: "ERROR";
    readonly REVERTED: "REVERTED";
    readonly FAILURE: "FAILURE";
};
export declare const PROJECT_CONFIG_FILE: "hsproject.json";
export declare const PROJECT_BUILD_STATES: {
    readonly BUILDING: "BUILDING";
    readonly ENQUEUED: "ENQUEUED";
    readonly FAILURE: "FAILURE";
    readonly PENDING: "PENDING";
    readonly SUCCESS: "SUCCESS";
};
export declare const PROJECT_DEPLOY_STATES: {
    readonly DEPLOYING: "DEPLOYING";
    readonly FAILURE: "FAILURE";
    readonly PENDING: "PENDING";
    readonly SUCCESS: "SUCCESS";
};
export declare const PROJECT_BUILD_TEXT: {
    readonly STATES: {
        readonly BUILDING: "BUILDING";
        readonly ENQUEUED: "ENQUEUED";
        readonly FAILURE: "FAILURE";
        readonly PENDING: "PENDING";
        readonly SUCCESS: "SUCCESS";
    };
    readonly STATUS_TEXT: "Building";
    readonly SUBTASK_KEY: "subbuildStatuses";
    readonly TYPE_KEY: "buildType";
    readonly SUBTASK_NAME_KEY: "buildName";
};
export declare const PROJECT_DEPLOY_TEXT: {
    readonly STATES: {
        readonly DEPLOYING: "DEPLOYING";
        readonly FAILURE: "FAILURE";
        readonly PENDING: "PENDING";
        readonly SUCCESS: "SUCCESS";
    };
    readonly STATUS_TEXT: "Deploying";
    readonly SUBTASK_KEY: "subdeployStatuses";
    readonly TYPE_KEY: "deployType";
    readonly SUBTASK_NAME_KEY: "deployName";
};
export declare const PROJECT_ERROR_TYPES: {
    readonly PROJECT_LOCKED: "BuildPipelineErrorType.PROJECT_LOCKED";
    readonly MISSING_PROJECT_PROVISION: "BuildPipelineErrorType.MISSING_PROJECT_PROVISION";
    readonly BUILD_NOT_IN_PROGRESS: "BuildPipelineErrorType.BUILD_NOT_IN_PROGRESS";
    readonly SUBBUILD_FAILED: "BuildPipelineErrorType.DEPENDENT_SUBBUILD_FAILED";
    readonly SUBDEPLOY_FAILED: "DeployPipelineErrorType.DEPENDENT_SUBDEPLOY_FAILED";
};
export declare const PROJECT_TASK_TYPES: {
    readonly PRIVATE_APP: "private app";
    readonly PUBLIC_APP: "public app";
    readonly APP_FUNCTION: "function";
    readonly CRM_CARD_V2: "card";
};
export declare const PROJECT_COMPONENT_TYPES: {
    readonly PROJECTS: "projects";
    readonly COMPONENTS: "components";
};
export declare const PLATFORM_VERSION_ERROR_TYPES: {
    readonly PLATFORM_VERSION_NOT_SPECIFIED: "PlatformVersionErrorType.PLATFORM_VERSION_NOT_SPECIFIED";
    readonly PLATFORM_VERSION_RETIRED: "PlatformVersionErrorType.PLATFORM_VERSION_RETIRED";
    readonly PLATFORM_VERSION_SPECIFIED_DOES_NOT_EXIST: "PlatformVersionErrorType.PLATFORM_VERSION_SPECIFIED_DOES_NOT_EXIST";
};
