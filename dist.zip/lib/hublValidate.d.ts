import { LintResult } from '@hubspot/local-dev-lib/types/HublValidation';
export declare function printHublValidationResult({ file, validation, }: LintResult): number;
