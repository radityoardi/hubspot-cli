export declare function resolveLocalPath(filepath: string): string;
export declare function isPathFolder(path: string): boolean;
