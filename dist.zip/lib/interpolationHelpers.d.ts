/**
 * These helper methods are used to modify text output within the CLI. They
 * should all take in a string value and output a modified string value.
 */
export declare function bold(stringValue: string): string;
export declare function yellow(stringValue: string): string;
export declare function green(stringValue: string): string;
export declare function red(stringValue: string): string;
export declare function cyan(stringValue: string): string;
export declare function orange(stringValue: string): string;
