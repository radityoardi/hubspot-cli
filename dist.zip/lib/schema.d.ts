import { Schema } from '@hubspot/local-dev-lib/types/Schemas';
export declare function logSchemas(schemas: Array<Schema>): void;
export declare function listSchemas(accountId: number): Promise<void>;
